# SI-GuidedProject-431204-1674104049
Flight Delay Prediction for aviation Industry using Machine Learning
https://drive.google.com/file/d/1mbLqkywcXqnV3Oii6gg3eORC2f65onqj/view?usp=share_link
